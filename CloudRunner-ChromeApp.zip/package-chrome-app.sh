#!/bin/bash
zip CloudRunner-ChromeApp *
