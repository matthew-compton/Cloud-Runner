Cloud Runner
=================

A simple game made with HTML5 Canvas.

It involves a friendly cloud named Cloudly and his adventures through the sky.

Dodge the unfriendly clouds and be sure to stay away from the evil Raincloud!

Setup Instructions
-------------

- Download the files locally

- Via the Chrome Web Store

    https://chrome.google.com/webstore/detail/cloud-runner/okafjkmanfganblclfhffedippdlnnmd

- Web-hosted version

    http://giantoctopus.gomobilecomputing.com/giantoctopus/cloudrunner/
