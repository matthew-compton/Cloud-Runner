HTML5-Canvas-Game
=================

Cloud Runner

A simple game made with HTML5 Canvas.

It involves a friendly cloud named Cloudly and his adventures through the sky.

Dodge the unfriendly clouds and be sure to stay away from the evil Raincloud!

=================

The game can be played by simply downloading the files locally, via the Chrome Web Store, or my hosted version at:

http://giantoctopus.gomobilecomputing.com/giantoctopus/cloudrunner/
